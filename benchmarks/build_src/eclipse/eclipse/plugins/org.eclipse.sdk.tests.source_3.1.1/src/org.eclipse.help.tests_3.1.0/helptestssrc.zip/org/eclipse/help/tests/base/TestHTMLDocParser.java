/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.base;
import java.io.*;
import java.net.*;

import org.eclipse.help.internal.protocols.*;
import org.eclipse.help.internal.search.*;
import org.eclipse.help.tests.*;
public class TestHTMLDocParser extends HelpSystemTestCase {
	public TestHTMLDocParser(String name) {
		super(name);
	}
	public void testHTMLDocParser_getCharsetFromHTML() throws Throwable {
		doTestHTMLDocParser_getCharsetFromHTML("noMeta.html", null);
		doTestHTMLDocParser_getCharsetFromHTML("UTF-8.html", "UTF-8");
		doTestHTMLDocParser_getCharsetFromHTML(
				"unquotedHTTP-EQUIVAtributeValue.html", "ISO-8859-1");
	}
	public void doTestHTMLDocParser_getCharsetFromHTML(String file,
			String expectedCharset) throws Throwable {
		HTMLDocParser parser = new HTMLDocParser();
		String href = "/org.eclipse.help.tests/data/HTMLDocParser/getCharsetFromHTML/"
				+ file;
		URL url = new URL("help", null, -1, href, HelpURLStreamHandler
				.getDefault());
		InputStream is = null;
		try {
			is = url.openStream();
			String charset = HTMLDocParser.getCharsetFromHTML(is);
			if (expectedCharset == null) {
				assertNull("Charset for document " + file + " is " + charset
						+ " instead of null.", charset);
			} else {
				assertTrue("Charset for document " + file + " is " + charset
						+ " instead of " + expectedCharset + ".",
						expectedCharset.equals(charset));
			}
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException ioe) {
				}
			}
		}
	}
	public void testHTMLDocParser_getCharsetFromHTTP() throws Throwable {
		doTestHTMLDocParser_getCharsetFromHTTP("", null);
		doTestHTMLDocParser_getCharsetFromHTTP("Content-Type:", null);
		doTestHTMLDocParser_getCharsetFromHTTP(
				"Content-Type: text/html; charset=ISO-8859-4", "ISO-8859-4");
		doTestHTMLDocParser_getCharsetFromHTTP(
				"Content-Type: text/html; charset= ISO-8859-4 ", "ISO-8859-4");
		doTestHTMLDocParser_getCharsetFromHTTP(
				"Content-Type: text/html; param=value; charset=ISO-8859-4;;",
				"ISO-8859-4");
	}
	private void doTestHTMLDocParser_getCharsetFromHTTP(String contentType,
			String expectedCharset) {
		HTMLDocParser parser = new HTMLDocParser();
		String charset = HTMLDocParser.getCharsetFromHTTP(contentType);
		if (expectedCharset == null) {
			assertNull("Charset for content type " + contentType + " is "
					+ charset + " instead of null.", charset);
		} else {
			assertTrue("Charset for content type " + contentType + " is "
					+ charset + " instead of " + expectedCharset + ".",
					expectedCharset.equals(charset));
		}
	}
}
