/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.webapp;
import java.io.*;
import java.net.*;

import org.eclipse.help.internal.appserver.*;
import org.eclipse.help.internal.base.*;
import org.eclipse.help.tests.*;
public class TestIndexing extends HelpSystemTestCase {
	// maximum allowed time for inexings [ms]
	private static final long MAX_INDEXING_TIME = 120 * 1000;
	public TestIndexing(String name) {
		super(name);
	}
	/**
	 * Sets up the fixture, for example, open a network connection. This method
	 * is called before a test is executed.
	 */
	protected final void helpSetUp() throws Exception {
		if (!BaseHelpSystem.ensureWebappRunning()) {
			throw new Exception("Cannot ensure webapp is running.");
		}
	}
	public void testIndexing() throws Throwable {
		String advancedSearchUrl = "/advanced/searchView.jsp?searchWord=trigger";
		String basicSearchUrl = "/basic/searchView.jsp?searchWord=trigger";

		// indexing in advanced
		URL url = new URL("http://" + WebappManager.getHost() + ":"
				+ WebappManager.getPort() + "/help" + advancedSearchUrl);
		HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();

		httpConn
				.setRequestProperty("User-Agent",
						"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705)");
		httpConn.connect();

		String waitStr = getContent(httpConn);
		httpConn.disconnect();
		assertTrue("Indexing not noticed in advanced UI.", waitStr
				.indexOf("setTimeout('refresh") > 0);

		// indexing in basic
		url = new URL("http://" + WebappManager.getHost() + ":"
				+ WebappManager.getPort() + "/help" + basicSearchUrl);
		httpConn = (HttpURLConnection) url.openConnection();
		httpConn.connect();

		waitStr = getContent(httpConn);
		httpConn.disconnect();
		assertTrue("Indexing not noticed in basic UI.", waitStr
				.indexOf("HTTP-EQUIV=\"REFRESH\"") > 0);

		// wait for end of indexing
		String results = waitStr;
		long indexingStart = System.currentTimeMillis();
		do {
			assertTrue("Indexing takes too long in advanced UI.", System
					.currentTimeMillis() < (indexingStart + MAX_INDEXING_TIME));
			Thread.sleep(2000);

			url = new URL("http://" + WebappManager.getHost() + ":"
					+ WebappManager.getPort() + "/help" + advancedSearchUrl);
			httpConn = (HttpURLConnection) url.openConnection();

			httpConn
					.setRequestProperty("User-Agent",
							"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705)");
			httpConn.connect();

			results = getContent(httpConn);
			httpConn.disconnect();
		} while (results.indexOf("setTimeout('refresh") > 0);
		// indexing finished in advaned UI
		url = new URL("http://" + WebappManager.getHost() + ":"
				+ WebappManager.getPort() + "/help" + basicSearchUrl);
		httpConn = (HttpURLConnection) url.openConnection();
		httpConn.connect();

		results = getContent(httpConn);
		httpConn.disconnect();
		assertTrue("Indexing not finished in basic UI.", results
				.indexOf("HTTP-EQUIV=\"REFRESH\"") < 0);

	}

	public void assertDocumentExists(HttpURLConnection httpConn)
			throws IOException {
		int responseCode = httpConn.getResponseCode();
		assertTrue("ResponseCode for " + httpConn.getURL() + " is "
				+ responseCode + " not 200.", responseCode == 200);
	}
	public String getContent(HttpURLConnection httpConn)
			throws UnsupportedEncodingException, IOException {
		assertDocumentExists(httpConn);

		Reader reader = new InputStreamReader(httpConn.getInputStream(),
				"UTF-8");
		StringBuffer strBuf = new StringBuffer();
		char buf[] = new char[4096];
		int n;
		while (0 <= (n = reader.read(buf))) {
			strBuf.append(buf, 0, n);
		}
		reader.close();
		String str = strBuf.toString();
		return str;
	}
}
