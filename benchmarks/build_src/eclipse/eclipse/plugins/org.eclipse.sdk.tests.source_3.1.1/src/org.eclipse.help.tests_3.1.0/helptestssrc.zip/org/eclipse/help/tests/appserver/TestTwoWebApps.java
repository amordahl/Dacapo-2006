/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.appserver;
import java.io.*;
import java.net.*;

import org.eclipse.core.runtime.*;
import org.eclipse.help.internal.appserver.*;
import org.eclipse.help.internal.protocols.*;
import org.eclipse.help.tests.*;

public class TestTwoWebApps extends HelpSystemTestCase {

	public TestTwoWebApps(String name) {
		super(name);
	}
	public void testOneServerTwoWebApps() throws Throwable {
		WebappManager.start("help", "org.eclipse.help.webapp", Path.EMPTY);
		WebappManager.start("help2", "org.eclipse.help.webapp", Path.EMPTY);
		String addr1 = "http://" + WebappManager.getHost() + ":"
				+ WebappManager.getPort() + "/help/content/";
		String addr2 = "http://" + WebappManager.getHost() + ":"
				+ WebappManager.getPort() + "/help2/content/";

		URL url1 = new URL("help", null, -1,
				"/org.eclipse.help.tests/ch1/t1.html", HelpURLStreamHandler
						.getDefault());
		URL url2 = new URL("help", null, -1,
				"/org.eclipse.help.tests/ch1/t1.html", HelpURLStreamHandler
						.getDefault());
		InputStream is1 = null;
		try {
			is1 = url1.openStream();
		} catch (IOException ioe) {
		}
		assertNotNull(is1);

		InputStream is2 = null;
		try {
			is2 = url2.openStream();
		} catch (IOException ioe) {
		}
		assertNotNull(is2);

		//System.out.println("url1:"+url1+"\n" + url1.getContent() );
		//System.out.println("url2:"+url2+"\n" );
		WebappManager.stop("help");
		WebappManager.stop("help2");
	}
}
