/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.base;
import org.eclipse.help.*;
import org.eclipse.help.internal.*;
import org.eclipse.help.tests.*;
public class TestContexts extends HelpSystemTestCase {
	public TestContexts(String name) {
		super(name);
	}
	public void testContextManager() throws Throwable {
		assertNotNull(HelpPlugin.getContextManager());
		assertNull(HelpSystem.getContext("missingContext"));
		IContext context = HelpSystem
				.getContext("org.eclipse.help.tests.testContext");
		assertNotNull(context);
		assertNotNull(context.getText());
		assertNotNull(context.getRelatedTopics());
		context = HelpPlugin.getContextManager().getContext(
				"org.eclipse.help.tests.testContextDescOnly");
		assertNotNull(context);
		assertNotNull(context.getText());
		assertNull(context.getRelatedTopics());

	}
}
