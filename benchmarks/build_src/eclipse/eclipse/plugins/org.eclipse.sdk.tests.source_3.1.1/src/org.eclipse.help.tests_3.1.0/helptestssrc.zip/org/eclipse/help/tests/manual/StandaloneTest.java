/*******************************************************************************
 * Copyright (c) 2003, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
/*
 * Run this class and press the buttons in the frame that pops up.
 * You can pass any options on the command line
 */
package org.eclipse.help.tests.manual;

import java.awt.*;
import java.awt.event.*;

import org.eclipse.help.standalone.*;

/**
 * Run this class and press the buttons in the frame that pops up.
 */
public class StandaloneTest {

	public static void main(String[] args) {
		try {

			// Test
			String[] options = args;
			if (args.length == 0) {
				options = new String[]{"-eclipsehome", "d:\\eclipse"};
			}
			final Help help = new Help(options);

			final Frame f = new Frame();
			Panel p = new Panel();
			p.setBackground(Color.white);
			p.setLayout(new GridLayout(5, 1));
			f.add(p);

			Label l = new Label("Select an action");
			l.setBackground(Color.white);
			p.add(l);

			Button b0 = new Button("start");
			p.add(b0);
			b0.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						help.start();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			});

			Button b1 = new Button("displayHelp");
			p.add(b1);
			b1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						help.displayHelp();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			});

			Button b2 = new Button("displayHelp: /org.eclipse.help/about.html");
			p.add(b2);
			b2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						help.displayHelp("/org.eclipse.help/about.html");
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			});

			Button b3 = new Button("shutdown");
			p.add(b3);
			b3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						help.shutdown();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			});

			f.addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent e) {
					f.dispose();
					try {
						help.shutdown();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					System.exit(0);
				}
			});

			f.pack();
			f.show();

			System.in.read();
			help.shutdown();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
