/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.standalone;
import java.io.*;
import java.net.*;

import org.eclipse.core.runtime.*;
import org.eclipse.help.internal.base.*;
import org.eclipse.help.internal.standalone.*;
import org.eclipse.help.tests.*;
public class TestInfocenter extends HelpSystemTestCase {
	String ECLIPSE_HOME;
	File data;
	public TestInfocenter(String name) {
		super(name);
	}
	/**
	 * Sets up the fixture, for example, open a network connection. This method
	 * is called before a test is executed.
	 */
	protected final void helpSetUp() throws Exception {
		ECLIPSE_HOME = Platform.getInstallLocation().getURL().getPath();

		data = new File(ECLIPSE_HOME, "infocenter-workspace");
	}
	/**
	 * Tears down the fixture, for example, close a network connection. This
	 * method is called after a test is executed.
	 */
	protected void helpTearDown() throws Exception {
	}
	public void testInfocenterLocales() throws Throwable {
		File connectionFile = new File(data, ".metadata/.connection");
		connectionFile.delete();

		String[] options = new String[]{"-eclipsehome", ECLIPSE_HOME,
				"-noexec", "-data", data.getAbsolutePath(), "-nl", "pl_PL",
				"-locales", "en", "en_CA"};
		Options.init(HelpBasePlugin.PLUGIN_ID + ".infocenterApplication",
				options);
		StandaloneInfocenter ic = new StandaloneInfocenter(options);
		System.out.println("Starting infocenter.");
		ic.start();
		System.out.println("Started infocenter.");
		EclipseConnection con = new EclipseConnection();
		try {
			con.renew();
		} catch (Exception e) {
			assertTrue(e.toString(), false);
		}
		assertTrue("Connection to Eclpse is not valid", con.isValid());

		localeReachedForLanguage("pl", "ja", con);
		localeReachedForLanguage("en", "en", con);
		localeReachedForLanguage("en", "en_CA", con);
		localeReachedForLanguage("en", "en_US", con);
		localeReachedForLanguage("pl", "pl-pl", con);

		System.out.println("Shutting down infocenter.");
		ic.shutdown();
		System.out.println("Shut down infocenter.");
		assertFalse("Connection file exists after shutdown", connectionFile
				.exists());
	}
	private void localeReachedForLanguage(String documentLocale,
			String clientAcceptLanguage, EclipseConnection con)
			throws MalformedURLException, IOException,
			UnsupportedEncodingException {
		String documentURL = "/topic/org.eclipse.help.tests/data/locale.html";
		URL url = new URL("http://" + con.getHost() + ":" + con.getPort()
				+ "/help" + documentURL);
		HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();

		httpConn.setRequestProperty("Accept-Language", clientAcceptLanguage);
		httpConn.connect();

		String str = getContent(httpConn);
		assertTrue("Topic from locale " + documentLocale
				+ " has not been retrieved for accept-language "
				+ clientAcceptLanguage + " > Contents retireved: " + str, str
				.indexOf("locale==" + documentLocale + ".") != -1);

		httpConn.disconnect();
	}

	public void assertDocumentExists(HttpURLConnection httpConn)
			throws IOException {
		int responseCode = httpConn.getResponseCode();
		assertTrue("ResponseCode for " + httpConn.getURL() + " is "
				+ responseCode + " not 200.", responseCode == 200);
	}

	public String getContent(HttpURLConnection httpConn)
			throws UnsupportedEncodingException, IOException {
		assertDocumentExists(httpConn);

		Reader reader = new InputStreamReader(httpConn.getInputStream(),
				"UTF-8");
		StringBuffer strBuf = new StringBuffer();
		char buf[] = new char[4096];
		int n;
		while (0 <= (n = reader.read(buf))) {
			strBuf.append(buf, 0, n);
		}
		reader.close();
		String str = strBuf.toString();
		return str;
	}
}
