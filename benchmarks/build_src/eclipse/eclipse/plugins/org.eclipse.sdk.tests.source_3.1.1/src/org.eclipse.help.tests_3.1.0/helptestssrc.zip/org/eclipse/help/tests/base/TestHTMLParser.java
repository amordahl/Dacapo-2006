/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.base;
import java.io.*;
import java.net.*;

import org.apache.lucene.demo.html.*;
import org.eclipse.help.internal.protocols.*;
import org.eclipse.help.tests.*;
public class TestHTMLParser extends HelpSystemTestCase {
	public TestHTMLParser(String name) {
		super(name);
	}
	public void testHTMLParser() throws Throwable {
	}
	public void testTitle() throws Throwable {
		textInFile("testtitle", true, "simple.html", true);
	}
	public void testBodyInTitle() throws Throwable {
		textInFile("testbody", false, "simple.html", true);
	}
	public void testBody() throws Throwable {
		textInFile("testtitle", true, "simple.html", true);
	}
	public void testP() throws Throwable {
		textInFile("testp", true, "simple.html", false);
	}
	public void testh2() throws Throwable {
		textInFile("testh2", true, "simple.html", false);
	}
	public void testh3() throws Throwable {
		textInFile("testh3", true, "simple.html", false);
	}
	public void testEnd() throws Throwable {
		textInFile("testend", true, "simple.html", false);
	}
	public void testDecl1() throws Throwable {
		textInFile("DOCTYPE", false, "simple.html", false);
	}
	public void testDecl2() throws Throwable {
		textInFile("HTML", false, "simple.html", false);
	}
	public void testDecl3() throws Throwable {
		textInFile("EN", false, "simple.html", false);
	}
	public void testHtmlTag() throws Throwable {
		textInFile("html", false, "simple.html", false);
	}
	public void testImg() throws Throwable {
		textInFile("img", false, "simple.html", false);
	}
	public void testImgAttr() throws Throwable {
		textInFile("height", false, "simple.html", false);
	}
	public void testImgAttr2() throws Throwable {
		textInFile("alt", false, "simple.html", false);
	}
	public void testImgAlt() throws Throwable {
		textInFile("imageDescription", true, "simple.html", false);
	}

	public void testXhtmlTitle() throws Throwable {
		textInFile("testtitle", true, "xhtml.html", true);
	}
	public void testXhtmlBody() throws Throwable {
		textInFile("testbody", true, "xhtml.html", false);
	}
	public void testXhtmlDecl1() throws Throwable {
		textInFile("?", false, "xhtml.html", false);
	}
	public void testXhtmlDecl2() throws Throwable {
		textInFile("xml", false, "xhtml.html", false);
	}
	public void testXhtmlDecl3() throws Throwable {
		textInFile("1.0", false, "xhtml.html", false);
	}
	public void testXhtmlDecl14() throws Throwable {
		textInFile("encoding", false, "xhtml.html", false);
	}
	public void testXhtmlDecl5() throws Throwable {
		textInFile("UTF-8", false, "xhtml.html", false);
	}

	public void testMetaKeywordsinTitle() throws Throwable {
		textInFile("key 1", false, "simple.html", true);
	}
	public void testMetaKeywordsinContent1() throws Throwable {
		textInFile(", ...", true, "simple.html", false);
	}
	public void testMetaKeywordsinContent2() throws Throwable {
		textInFile("meta", false, "simple.html", false);
	}
	public void testMetaKeywordsinContent3() throws Throwable {
		textInFile("name", false, "simple.html", false);
	}
	public void testMetaKeywordsinContent4() throws Throwable {
		textInFile("keywords", false, "simple.html", false);
	}
	public void testMetaKeywordsinContent5() throws Throwable {
		textInFile("content", false, "simple.html", false);
	}
	private void textInFile(String text, boolean present, String file,
			boolean inTitle) throws Throwable {
		String href = "/org.eclipse.help.tests/data/HTMLParser/" + file;
		URL url = new URL("help", null, -1, href, HelpURLStreamHandler
				.getDefault());
		Reader fileReader = null;
		try {
			fileReader = new InputStreamReader(url.openStream(), "UTF-8");
			HTMLParser parser = new HTMLParser(fileReader);
			if (inTitle) {
				String title = parser.getTitle();
				assertNotNull(title);
				assertFalse(present ^ title.indexOf(text) >= 0);
			} else {
				Reader contentsReader = parser.getReader();
				assertNotNull(contentsReader);
				StringBuffer b = new StringBuffer();
				int n;
				char[] buf = new char[1024];
				try {
					while ((n = contentsReader.read(buf)) >= 0) {
						b.append(buf, 0, n);
					}
				} catch (IOException ioe) {
				} finally {
					contentsReader.close();
				}
				String contents = b.toString();
				assertFalse(present ^ contents.indexOf(text) >= 0);
			}
		} finally {
			if (fileReader != null) {
				try {
					fileReader.close();
				} catch (IOException ioe) {
				}
			}
		}
	}
}
