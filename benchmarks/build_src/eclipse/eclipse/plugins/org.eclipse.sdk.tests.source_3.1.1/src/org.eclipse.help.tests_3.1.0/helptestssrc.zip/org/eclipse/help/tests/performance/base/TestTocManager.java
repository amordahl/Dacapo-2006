/*******************************************************************************
 * Copyright (c) 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.performance.base;

import java.util.ArrayList;
import java.util.Collection;

import org.eclipse.help.internal.toc.*;
import org.eclipse.help.tests.performance.*;
//import org.eclipse.test.performance.*;

public class TestTocManager extends HelpSystemPerformanceTestCase {
	class TestableTocManager extends TocManager {
		protected Collection getContributedTocFiles(String locale) {
			Collection col = new ArrayList();
			col.add(new TocFile("org.eclipse.help.tests", "performancetoc.xml",
					true, "en_US", null));
			return col;
		}
	}
	public TestTocManager(String name) {
		super(name);
	}

	public void testTocManager() {
		// tagAsGlobalSummary("Build Help TOCs", Dimension.ELAPSED_PROCESS); //$NON-NLS-1$
		for (int i = 0; i < 10; i++) {
			startMeasuring();
			for (int t = 0; t < 100; t++) {
				TocManager tocManager = new TestableTocManager();
				tocManager.getTocs("en_US");
			}
			stopMeasuring();
		}
		commitMeasurements();
		assertPerformance();
	}
}
