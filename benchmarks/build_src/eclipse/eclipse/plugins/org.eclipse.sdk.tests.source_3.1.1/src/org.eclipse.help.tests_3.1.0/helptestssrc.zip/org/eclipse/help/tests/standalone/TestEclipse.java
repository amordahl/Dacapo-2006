/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.standalone;
import java.io.*;

import org.eclipse.core.runtime.*;
import org.eclipse.help.internal.standalone.*;
import org.eclipse.help.tests.*;
public class TestEclipse extends HelpSystemTestCase {
	String ECLIPSE_HOME;
	File data;
	public TestEclipse(String name) {
		super(name);
	}
	/**
	 * Sets up the fixture, for example, open a network connection. This method
	 * is called before a test is executed.
	 */
	protected final void helpSetUp() throws Exception {
		ECLIPSE_HOME = Platform.getInstallLocation().getURL().getPath();

		data = new File(ECLIPSE_HOME, "standalone-workspace");
	}
	/**
	 * Tears down the fixture, for example, close a network connection. This
	 * method is called after a test is executed.
	 */
	protected void helpTearDown() throws Exception {
	}
	public void testStartShutdown() throws Throwable {
		File connectionFile = new File(data, ".metadata/.connection");
		connectionFile.delete();

		String[] options = new String[]{"-eclipsehome", ECLIPSE_HOME,
				"-noexec", "-ws", Platform.getWS(), "-data", data.getAbsolutePath()};
		StandaloneHelp help = new StandaloneHelp(options);
		System.out.println("Starting standalone help.");
		help.start();
		System.out.println("Started standalone help.");
		EclipseConnection con = new EclipseConnection();
		try {
			con.renew();
		} catch (Exception e) {
			assertTrue(e.toString(), false);
		}
		assertTrue("Connection to Eclpse is not valid", con.isValid());

		System.out.println("Shutting down standalone help.");
		help.shutdown();
		System.out.println("Shut down standalone help.");
		assertFalse("Connection file exists after shutdown", connectionFile
				.exists());
	}
}
