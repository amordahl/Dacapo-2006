/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.webapp;
import java.io.*;
import java.net.*;

import org.eclipse.help.internal.appserver.*;
import org.eclipse.help.internal.base.*;
import org.eclipse.help.tests.*;
public class TestFrames extends HelpSystemTestCase {
	public TestFrames(String name) {
		super(name);
	}
	/**
	 * Sets up the fixture, for example, open a network connection. This method
	 * is called before a test is executed.
	 */
	protected final void helpSetUp() throws Exception {
		if (!BaseHelpSystem.ensureWebappRunning()) {
			throw new Exception("Cannot ensure webapp is running.");
		}
	}
	public void testAdvancedBrowser() throws Throwable {
		String documentURL = "/";
		URL url = new URL("http://" + WebappManager.getHost() + ":"
				+ WebappManager.getPort() + "/help" + documentURL);
		HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();

		httpConn
				.setRequestProperty("User-Agent",
						"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705)");
		httpConn.connect();

		String str = getContent(httpConn);
		assertTrue("Basic content served to advanced browser.", str
				.indexOf("advanced/help.jsp") > 0);

		httpConn.disconnect();
	}
	public void testBasicBrowser() throws Throwable {
		String documentURL = "/";
		URL url = new URL("http://" + WebappManager.getHost() + ":"
				+ WebappManager.getPort() + "/help" + documentURL);
		HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();

		//httpConn.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible;
		// MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705)");
		httpConn.connect();

		String str = getContent(httpConn);
		assertTrue("Advanced content served to basic browser.", str
				.indexOf("basic/help.jsp") > 0);

		httpConn.disconnect();
	}

	public void testTopicOpensFrames() throws Throwable {
		String documentURL = "/topic/org.eclipse.help.tests/intro.html";
		URL url = new URL("http://" + WebappManager.getHost() + ":"
				+ WebappManager.getPort() + "/help" + documentURL);
		HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();

		httpConn
				.setRequestProperty("User-Agent",
						"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705)");
		httpConn.connect();

		String str = getContent(httpConn);
		assertTrue("Topic not displayed in frames", str
				.indexOf("location.replace") > 0);
		assertTrue("Topic not displayed in frames", str.indexOf("topic=") > 0);
		assertTrue("Topic not displayed in frames", str
				.indexOf("org.eclipse.help.tests") > 0);

		httpConn.disconnect();
	}

	public void testTopicNoFrames() throws Throwable {
		String documentURL = "/topic/org.eclipse.help.tests/intro.html?noframes=true";
		URL url = new URL("http://" + WebappManager.getHost() + ":"
				+ WebappManager.getPort() + "/help" + documentURL);
		HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();

		httpConn
				.setRequestProperty("User-Agent",
						"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705)");
		httpConn.connect();

		String str = getContent(httpConn);
		assertTrue("noframes=true displays frames.",
				str.indexOf("<frameset") < 0);
		assertTrue("noframes=true document replaced with frames.", str
				.indexOf("location.replace") < 0);

		httpConn.disconnect();
	}

	public void assertDocumentExists(HttpURLConnection httpConn)
			throws IOException {
		int responseCode = httpConn.getResponseCode();
		assertTrue("ResponseCode for " + httpConn.getURL() + " is "
				+ responseCode + " not 200.", responseCode == 200);
	}
	public String getContent(HttpURLConnection httpConn)
			throws UnsupportedEncodingException, IOException {
		assertDocumentExists(httpConn);

		Reader reader = new InputStreamReader(httpConn.getInputStream(),
				"UTF-8");
		StringBuffer strBuf = new StringBuffer();
		char buf[] = new char[4096];
		int n;
		while (0 <= (n = reader.read(buf))) {
			strBuf.append(buf, 0, n);
		}
		reader.close();
		String str = strBuf.toString();
		return str;
	}
}
