/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.dynamic;

import java.io.*;
import java.util.*;

import org.eclipse.help.*;

/**
 * Test dynamic topic.
 */
public class DynamicTopics implements IHelpContentProducer {
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.help.ITopicContent#getInputStream()
	 */
	public InputStream getInputStream(String pluginID, String name,
			Locale locale) {
		if (name.indexOf("dynamic") < 0) {
			return null;
		}
		String content = "<html><body>Dynamic content for topic " + name
				+ ".<br>Generated " + new Date().toString() + ".</body></html>";
		try {
			return new ByteArrayInputStream(content.getBytes("UTF8"));
		} catch (UnsupportedEncodingException uee) {
			// never here
			return null;
		}
	}

}
