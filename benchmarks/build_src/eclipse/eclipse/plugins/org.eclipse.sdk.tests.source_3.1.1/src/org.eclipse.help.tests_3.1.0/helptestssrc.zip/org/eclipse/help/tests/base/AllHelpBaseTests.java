/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.base;
import junit.framework.*;
public class AllHelpBaseTests {
	public static Test suite() {
		TestSuite suite = new TestSuite();
		suite.setName("All Help System Base Tests");
		suite.addTest(new TestSuite(TestHelpSystem.class));
		suite.addTest(new TestSuite(TestTocs.class));
		suite.addTest(new TestSuite(TestContexts.class));
		suite.addTest(new TestSuite(TestHelpUrls.class));
		suite.addTest(new TestSuite(TestHTMLParser.class));
		suite.addTest(new TestSuite(TestHTMLDocParser.class));
		suite.addTest(new TestSuite(TestLogFile.class));
		return suite;
	}
}
