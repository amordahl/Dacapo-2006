/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.livehelp;
import org.eclipse.help.browser.*;
import org.eclipse.help.internal.appserver.*;
import org.eclipse.help.internal.base.*;
import org.eclipse.help.internal.browser.*;
import org.eclipse.help.tests.*;
import org.eclipse.swt.widgets.*;
public class TestLiveHelp extends HelpSystemTestCase {
	static boolean actionCompleted;
	public TestLiveHelp(String name) {
		super(name);
	}
	/**
	 * Sets up the fixture, for example, open a network connection. This method
	 * is called before a test is executed.
	 */
	protected final void helpSetUp() throws Exception {
		if (!BaseHelpSystem.ensureWebappRunning()) {
			throw new Exception("Cannot ensure webapp is running.");
		}
	}
	public void testLiveHelp() throws Throwable {
		IBrowser iebrowser = BrowserManager.getInstance().createBrowser(false);
		assertNotNull(iebrowser);

		iebrowser
				.displayURL("http://"
						+ WebappManager.getHost()
						+ ":"
						+ WebappManager.getPort()
						+ "/help/index.jsp?topic=/org.eclipse.help.tests/livehelp/testLiveHelp.html");

		// Give the browser enough time to load the document and execute action
		long documentOpened = System.currentTimeMillis();
		while (!actionCompleted) {
			try {
				// This is needed when running JUnit in the workspace
				// otherwise browser IE is frozen and will not load the
				// document
				Display d = Display.getCurrent();
				if (d != null) {
					while (d.readAndDispatch()) {
					}
					d.sleep();
				} else {
					Thread.sleep(500);
				}
			} catch (Exception e) {
			}
			if (System.currentTimeMillis() > documentOpened + 60000) {
				break;
			}
		}
		iebrowser.close();
		assertTrue("LiveHelpAction not executed.", actionCompleted);
	}
	public static void action() {
		System.out.println("TestLiveHelp.action()");
		actionCompleted = true;
	}
}
