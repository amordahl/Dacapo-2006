/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.performance;
import java.io.*;
import java.util.*;

import junit.framework.*;

import org.eclipse.core.runtime.*;
import org.eclipse.help.internal.*;
import org.eclipse.test.performance.*;
public abstract class HelpSystemPerformanceTestCase extends PerformanceTestCase {
	protected boolean initialized;
	protected File HELP_METADATA_DIR;
	public HelpSystemPerformanceTestCase(String name) {
		super(name);
		init();
	}
	protected void init() {
		// Set HELP_METADATA_DIR
		IPath metaData = HelpPlugin.getDefault().getStateLocation();
		HELP_METADATA_DIR = metaData.toFile();

	}
	/**
	 * Simple implementation of setUp. Subclasses are prevented from overriding
	 * this method to maintain logging consistency. helpSetUp() should be
	 * overriden instead.
	 */
	protected final void setUp() throws Exception {
		super.setUp();
		System.out.println("----- " + this.getName());
		System.out.println(this.getName() + ": setUp...");
		helpSetUp();
	}
	/**
	 * Sets up the fixture, for example, open a network connection. This method
	 * is called before a test is executed.
	 */
	protected void helpSetUp() throws Exception {
		// do nothing.
	}
	/**
	 * Simple implementation of tearDown. Subclasses are prevented from
	 * overriding this method to maintain logging consistency. helpTearDown()
	 * should be overriden instead.
	 */
	protected final void tearDown() throws Exception {
		System.out.println(this.getName() + ": tearDown...\n");
		helpTearDown();
		super.tearDown();
	}
	/**
	 * Tears down the fixture, for example, close a network connection. This
	 * method is called after a test is executed.
	 */
	protected void helpTearDown() throws Exception {
		// do nothing.
	}
	/**
	 * Compares two directories for identical content. Takes optional (can be
	 * null) FilenameFilter
	 */
	public static void assertDirectoriesSame(File dir1, File dir2,
			FilenameFilter filter) throws Throwable {
		if (!dir1.exists() && !dir2.exists()) {
			throw new AssertionFailedError("Directories " + dir1 + " and "
					+ dir2 + " do not exist.");
		}
		if (!dir1.exists()) {
			throw new AssertionFailedError("Directories " + dir1 + " and "
					+ dir2 + " differ. Directory " + dir1 + " does not exist.");
		}
		if (!dir2.exists()) {
			throw new AssertionFailedError("Directories " + dir1 + " and "
					+ dir2 + " differ. Directory " + dir2 + " does not exist.");
		}
		File[] allFiles1;
		File[] allFiles2;
		if (filter != null) {
			allFiles1 = dir1.listFiles(filter);
			allFiles2 = dir2.listFiles(filter);
		} else {
			allFiles1 = dir1.listFiles();
			allFiles2 = dir2.listFiles();
		}
		Collection allFileNames1 = new ArrayList(allFiles1.length);
		Collection allFileNames2 = new ArrayList(allFiles2.length);
		for (int i = 0; i < allFiles1.length; i++)
			allFileNames1.add(allFiles1[i].getName());
		for (int i = 0; i < allFiles2.length; i++)
			allFileNames2.add(allFiles2[i].getName());
		// compare dir1 to dir2
		for (int i = 0; i < allFiles1.length; i++) {
			if (allFileNames2.contains(allFiles1[i].getName())) {
				File file2 = new File(dir2, allFiles1[i].getName());
				if (allFiles1[i].isDirectory() && file2.isDirectory()) {
					assertDirectoriesSame(allFiles1[i], file2, filter);
					continue;
				} else if (!allFiles1[i].isDirectory() && !file2.isDirectory()) {
					assertTextFilesSame(allFiles1[i], file2);
					continue;
				} else if (allFiles1[i].isDirectory() && !file2.isDirectory()) {
					throw new AssertionFailedError("Directories " + dir1
							+ " and " + dir2 + " differ. File "
							+ allFiles1[i].getName() + " is a directory in "
							+ dir1 + ", and a file in " + dir2 + ".");
				} else { //if(!allFiles1[i].isDirectory() &&
					// file2.isDirectory())
					throw new AssertionFailedError("Directories " + dir1
							+ " and " + dir2 + " differ. File "
							+ allFiles1[i].getName() + " is a file in " + dir1
							+ ", and a directory in " + dir2 + ".");
				}
			} else {
				throw new AssertionFailedError("Directories " + dir1 + " and "
						+ dir2 + " differ. File " + allFiles1[i].getName()
						+ " does not exist in " + dir2 + ".");
			}
		}
		for (int i = 0; i < allFiles2.length; i++) {
			if (allFileNames1.contains(allFiles2[i].getName())) {
				// comparison already done above
			} else {
				throw new AssertionFailedError("Directories " + dir1 + " and "
						+ dir2 + " differ. File " + allFiles2[i].getName()
						+ " does not exist in " + dir1 + ".");
			}
		}

	}
	public static void assertTextFilesSame(File file1, File file2)
			throws Throwable {
		if (!file1.exists() && !file2.exists()) {
			throw new AssertionFailedError("Files " + file1 + " and " + file2
					+ " do not exist.");
		}
		if (!file1.exists()) {
			throw new AssertionFailedError("Files " + file1 + " and " + file2
					+ " differ. File " + file1 + " does not exist.");
		}
		if (!file2.exists()) {
			throw new AssertionFailedError("Files " + file1 + " and " + file2
					+ " differ. File " + file2 + " does not exist.");
		}
		try {
			BufferedReader reader1 = new BufferedReader(new InputStreamReader(
					new FileInputStream(file1), "UTF-8"));
			BufferedReader reader2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(file2), "UTF-8"));
			String line1;
			String line2;
			int lineNumber = 1;
			do {
				line1 = reader1.readLine();
				line2 = reader2.readLine();
				if (line1 == null && line2 == null)
					return;
				if (line1 == null || line2 == null || !line1.equals(line2)) {
					throw new AssertionFailedError("Files " + file1 + " and "
							+ file2 + " differ at line " + lineNumber + ".");
				}
				lineNumber++;
			} while (true);
		} catch (IOException ioe) {
			System.out.println("IOException comparing files " + file1 + " and "
					+ file2);
			ioe.printStackTrace();
			throw ioe;
		}
	}
}
