/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.simplerealm;

import java.util.Map;

import org.apache.catalina.Realm;
import org.apache.catalina.realm.MemoryRealm;
import org.eclipse.core.runtime.*;
import org.eclipse.tomcat.internal.extensions.IRealmFactory;

/**
 * Factory for generating an appropriate realm for authenticating using the info
 * in c:/tomcat-users.xml. Intended to be a simple test plugin for the new Realm
 * support for the help subsystem.
 */
public class SimpleRealmFactory implements IRealmFactory, IExecutableExtension {
	private IConfigurationElement config = null;

	private Map parameters = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.core.runtime.IExecutableExtension#setInitializationData(org.eclipse.core.runtime.IConfigurationElement,
	 *      java.lang.String, java.lang.Object)
	 */
	public void setInitializationData(IConfigurationElement config,
			String propertyName, Object data) throws CoreException {
		this.config = config;
		parameters = (Map) data;
	}

	/**
	 * Creates a realm appropriate for authenticating using the path specified
	 * in the userDefFile parameter.
	 * 
	 * @see org.eclipse.tomcat.internal.extensions.IRealmFactory#createRealm(org.eclipse.tomcat.internal.extensions.ConfigurationInfo[])
	 */
	public Realm createRealm() {
		MemoryRealm retVal = new MemoryRealm();
		IConfigurationElement[] parameters = config.getChildren();
		String filepath = null;
		// for (int i =0; i < parameters.length; i++) {
		// if ("userDefinitionFile".equals(parameters[i].getAttribute("name")))
		// {
		// filepath = parameters[i].getAttribute("value");
		// }
		// }
		if (filepath != null) {
			retVal.setPathname(filepath);
		}
		return retVal;
	}

}
