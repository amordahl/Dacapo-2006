/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.base;
import java.io.*;
import java.net.*;

import org.eclipse.help.internal.protocols.*;
import org.eclipse.help.tests.*;
public class TestHelpUrls extends HelpSystemTestCase {
	public TestHelpUrls(String name) {
		super(name);
	}
	public void testHelpUrl() throws Throwable {
		String href = ("/org.eclipse.help.tests/ch1/t1.html");
		URL url = new URL("help", null, -1, href, HelpURLStreamHandler
				.getDefault());

		InputStream is1 = null;
		try {
			is1 = url.openStream();
		} catch (IOException ioe) {
		}
		assertNotNull(is1);
	}
	public void testHelpUrlFail() throws Throwable {
		String href = "/org.eclipse.help.tests/nosuchfile.html";
		URL url = new URL("help", null, -1, href, HelpURLStreamHandler
				.getDefault());
		InputStream is1 = null;
		try {
			is1 = url.openStream();
		} catch (IOException ioe) {
		}
		assertNull(is1);

		href = "/org.eclipse.help.tests/nosuchfile.xxx";
		url = new URL("help", null, -1, href, HelpURLStreamHandler.getDefault());
		InputStream is2 = null;
		try {
			is2 = url.openStream();
		} catch (IOException ioe) {
		}
		assertNull(is2);

	}
	//	public void testTocUrl() throws Throwable {
	//		// get one TOC
	//		URL url=new URL("help:/toc/org.eclipse.help.tests/testbook.xml");
	//		assertNotNull(url.openStream());
	//		// get list of TOCs
	//		url=new URL("help:/toc/");
	//		assertNotNull(url.openStream());
	//	}
	public void testTocUrlFail() throws Throwable {
		String href = "/toc/org.eclipse.help.tests/ch1/t1.html";
		URL url = new URL("help", null, -1, href, HelpURLStreamHandler
				.getDefault());
		InputStream is1 = null;
		try {
			is1 = url.openStream();
		} catch (IOException ioe) {
		}
		assertNull(is1);

		href = "/toc";
		url = new URL("help", null, -1, href, HelpURLStreamHandler.getDefault());
		InputStream is2 = null;
		try {
			is2 = url.openStream();
		} catch (IOException ioe) {
		}
		assertNull(is2);
	}
}
