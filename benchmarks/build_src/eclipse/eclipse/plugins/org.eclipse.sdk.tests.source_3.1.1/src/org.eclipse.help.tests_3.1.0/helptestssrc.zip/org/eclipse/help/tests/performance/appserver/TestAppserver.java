/*******************************************************************************
 * Copyright (c) 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.performance.appserver;

import org.eclipse.core.runtime.*;
import org.eclipse.help.internal.appserver.*;
import org.eclipse.help.tests.performance.*;

public class TestAppserver extends HelpSystemPerformanceTestCase {
	public TestAppserver(String name) {
		super(name);
	}

	public void testAppserverCycle() {
		try {
			AppserverPlugin.getDefault().getAppServer().start(0, "127.0.0.1");
			AppserverPlugin.getDefault().getAppServer().stop();
		} catch (CoreException ce) {
			ce.printStackTrace();
		}
		for (int i = 0; i < 10; i++) {
			startMeasuring();
			for (int t = 0; t < 80; t++) {
				try {
					AppserverPlugin.getDefault().getAppServer().start(0,
							"127.0.0.1");
					AppserverPlugin.getDefault().getAppServer().stop();
				} catch (CoreException ce) {
					ce.printStackTrace();
				}
			}
			stopMeasuring();
		}
		commitMeasurements();
		assertPerformance();
	}
}
