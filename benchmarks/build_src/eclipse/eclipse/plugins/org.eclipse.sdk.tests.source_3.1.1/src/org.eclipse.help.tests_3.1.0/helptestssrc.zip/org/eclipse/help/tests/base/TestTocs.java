/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.help.tests.base;
import java.util.*;

import org.eclipse.help.*;
import org.eclipse.help.internal.*;
import org.eclipse.help.internal.toc.*;
import org.eclipse.help.tests.*;
public class TestTocs extends HelpSystemTestCase {
	public TestTocs(String name) {
		super(name);
	}
	public void testNumberOfTocs() throws Throwable {
		TocManager tman = HelpPlugin.getTocManager();
		assertNotNull(tman);
		IToc[] tocs = tman.getTocs(Locale.getDefault().toString());
		assertNotNull(tocs);
		assertTrue(1 < tocs.length);
		// fail to obtain non existing toc
		IToc toc = tman.getToc("/org.eclipse.help.tests/standalonesection.xml",
				Locale.getDefault().toString());
		assertNull(toc);
	}
	public void testExtraDir() throws Throwable {
		TocManager tman = HelpPlugin.getTocManager();
		IToc[] tocs = tman.getTocs(Locale.getDefault().toString());
		assertNotNull(tocs);
		IToc toc = tman.getToc("/org.eclipse.help.tests/testbook.xml", Locale
				.getDefault().toString());
		assertNotNull(toc);
		assertTrue(toc instanceof Toc);
		assertTrue(((Toc) toc).getExtraTopics().length > 0);
	}
	public void testObtainToc() throws Throwable {
		TocManager tman = HelpPlugin.getTocManager();
		IToc toc = tman.getToc("/org.eclipse.help.tests/testbook.xml", "en_US");
		assertNotNull(toc);
		String href = toc.getHref();
		assertNotNull(href);
		assertTrue(!"".equals(href));
		String label = toc.getLabel();
		assertNotNull(label);
		assertTrue(!"".equals(label));
		ITopic[] topics = toc.getTopics();
		assertNotNull(topics);
		assertTrue(topics.length > 0);
	}
}
