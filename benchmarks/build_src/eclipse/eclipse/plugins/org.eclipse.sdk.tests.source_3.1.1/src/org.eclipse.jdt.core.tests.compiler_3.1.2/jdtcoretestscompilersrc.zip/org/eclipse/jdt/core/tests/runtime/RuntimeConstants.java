/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.jdt.core.tests.runtime;

public interface RuntimeConstants {
	public static final String SUPPORT_ZIP_FILE_NAME = "EvalTestsTarget.zip";
	public static final String CODE_SNIPPET_RUNNER_CLASS_NAME = "org.eclipse.jdt.core.tests.eval.target.CodeSnippetRunner";
	public static final String RUN_CODE_SNIPPET_METHOD = "runCodeSnippet";
	public static final String THE_RUNNER_FIELD = "theRunner";
	public static final String EVALPORT_ARG = "-evalport";
	public static final String CODESNIPPET_CLASSPATH_ARG = "-cscp";
	public static final String CODESNIPPET_BOOTPATH_ARG = "-csbp";
}
