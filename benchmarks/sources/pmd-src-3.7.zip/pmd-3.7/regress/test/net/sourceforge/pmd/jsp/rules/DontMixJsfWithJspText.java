package test.net.sourceforge.pmd.jsp.rules;

import test.net.sourceforge.pmd.testframework.SimpleAggregatorTst;

public class DontMixJsfWithJspText extends SimpleAggregatorTst {

}
