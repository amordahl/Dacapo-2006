#!/bin/bash

scp *.html tomcopeland@pmd.sf.net:/home/groups/p/pm/pmd/htdocs/fr/
