Please see the documentation in the docs directory or at http://pmd.sf.net/.

Using PMD?  Get the book!  http://pmdapplied.com/
