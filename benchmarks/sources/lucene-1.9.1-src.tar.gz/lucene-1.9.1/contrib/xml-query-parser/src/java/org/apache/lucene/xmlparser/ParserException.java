/*
 * Created on 25-Jan-2006
 */
package org.apache.lucene.xmlparser;

/**
 * @author maharwood
 */
public class ParserException extends Exception {

	/**
	 * 
	 */
	public ParserException() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param message
	 */
	public ParserException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param message
	 * @param cause
	 */
	public ParserException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param cause
	 */
	public ParserException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
